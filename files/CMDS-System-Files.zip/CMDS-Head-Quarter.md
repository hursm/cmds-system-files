---
type: CMDS
aliases:
  - CMDS HQ
  - Head Quarter
description: Central navigation hub for the CMDS vault. Provides links to 91 sub-categories across 9 main categories (100-900), a CMDS Process summary, vault folder structure (00-90), and working environment information. Reference when navigating the vault or locating a specific category.
author:
  - "[[구요한]]"
date created: 2025-10-23T01:59
date modified: 2026-04-14T22:13
tags:
  - CMDS
  - system
audience: User (구요한)
scope: navigation
precedence: 5
memory-type: reference
required-for:
  - navigation
optional-for:
  - context-understanding
  - code-generation
token-estimate: 1800
index: "[[🏛 CMDS Guide]]"
version: "1.2"
status: completed
changelog:
  - "1.2 (2026-04-07): description 필드 English 규칙 적용"
  - "1.1 (2026-04-01): precedence/memory-type/token-estimate 추가"
  - "1.0 (2026-03-15): CMDS Process 설명 추가, Vault Folders 섹션 추가"
share_link: https://share.note.sx/fhfd1sg3#k4DqRdPCseLgf3fC7XlKzkIs/Hr5ZLdr/R6f5vlVJN0
share_updated: 2025-08-25T11:43:35+09:00
---
> **🔄 Last Updated: 2026-04-01** | Backup: `40. Docs/47. CMDS Docs/cmds-system-files/CMDS-Head-Quarter_backup.md`

Links:: [[🏛 CMDS Head Quarter]] | [[🏛 CMDS Guide]]
References:: [[🏛 000 YHN Home]]
## CMDS
- #### [[📖 100 Themes]]
	- [[📚 101 Interests]]
	- [[📚 102 Topics]]
	- [[📚 103 Variables]]
	- [[📚 104 Terminologies]]
- #### [[📖 200 Literature]]
	- [[📚 201 Concepts]]
	- [[📚 202 Frameworks]]
	- [[📚 203 Models]]
	- [[📚 204 Theories]] 
	- [[📚 205 Classics]] 
	- [[📚 210 Literature Reviews]]
	- [[📚 220 Personal Insights]]
	- [[📚 240 Books]]
	- [[📚 290 Bible]]
	- [[📚 291 Sermon]]
- #### [[📖 300 Data]]
    - [[📚 301 Scale Development and Validation]]
    - [[📚 302 Questionnaires]]
    - [[📚 303 Panel Data]]
	- [[📚 310 Data Management]]
	- [[📚 311 Database Systems]]
	- [[📚 330 Learning Management Systems]]
- #### [[📖 400 Methodologies]]
	- [[📚 401 Research Methods]]
	- [[📚 402 Quantitative Research]]
	- [[📚 403 Experimental Research]]
	- [[📚 404 Qualitative Research]]
	- [[📚 405 Mixed Methods]]
	- [[📚 410 Statistical Inference]]
	- [[📚 411 Regression Analysis]]
	- [[📚 412 Causal Inference]]
	- [[📚 420 Machine Learning]]
	- [[📚 421 Time Series Analysis]]
	- [[📚 422 Deep Learning]]
	- [[📚 423 Predictive Analytics]]
	- [[📚 490 Syntax]]
	- [[📚 491 Codes]] 
	- [[📚 492 Prompts]] 
	- [[📚 493 Scripts]] 
- #### [[📖 500 Products]]
	- [[📚 501 Obsidian]]
	- [[📚 502 Notion]]
	- [[📚 510 DevonThink]]
	- [[📚 520 ChatGPT]]
	- [[📚 521 Claude]]
	- [[📚 522 Gemini]]
	- [[📚 523 LLaMa]]
	- [[📚 530 Midjourney]]
	- [[📚 531 Stable Diffusion]]
	- [[📚 541 n8n]]
- #### [[📖 600 Specialties]]
	- [[📚 601 Knowledge Management]]
	- [[📚 603 Second Brain]]
	- [[📚 604 ZettelKasten]]
	- [[📚 610 Productivity]]
	- [[📚 620 Generative AI]]
	- [[📚 630 Development]]
	- [[📚 651 Physical Health]]
	- [[📚 652 Mental Health]]
	- [[📚 653 Biohacking]]
	- [[📚 680 Educations]]
	- [[📚 690 Spirituality]]
- #### [[📖 700 Creatives]]
	- [[📚 701 YouTube]]
	- [[📚 710 SNS]]
	- [[📚 720 Music]]
	- [[📚 721 Jazz]]
	- [[📚 730 Images]]
	- [[📚 731 Digital Art and Design]]
- #### [[📖 800 Outputs]]
	- [[📚 801 PhD]]
	- [[📚 802 Articles]]
	- [[📚 803 Books]]
	- [[📚 804 Community]]
	- [[📚 805 Group Study]]
	- [[📚 806 Webpages]]
	- [[📚 820 Research]]
	- [[📚 821 Academic Journals]]
	- [[📚 822 Conference Presentations]]
	- [[📚 830 Projects]]
	- [[📚 831 Consulting]]
	- [[📚 840 Lectures]]
	- [[📚 841 Curriculum]]
	- [[📚 842 Course Development and Resources]]
	- [[📚 843 Class Administration and Management]]
- #### [[📖 900 Divisions]]
	- [[📚 901 Knowledge Management & Research Division]]
	- [[📚 902 Editorial & Content Creation Division]]
	- [[📚 903 Education & Training Division]]
	- [[📚 904 Creative Arts & Media Division]]
	- [[📚 905 Data Science & Analytics Division]]
	- [[📚 906 Partnerships & Outreach Division]]
	- [[📚 907 Technology & Development Division]]
	- [[📚 908 Events & Community Engagement Division]]
	- [[📚 909 Consulting & Professional Services Division]]
## CMDS Process
#### CMDS Process란?
- **Connect**: 관심사와 주제를 연결하여 아이디어를 발굴하는 단계
- **Merge**: 관련 문헌과 지식을 통합하여 이론적 기반을 구축하는 단계
- **Develop**: 데이터를 수집하고 방법론을 적용하여 아이디어를 개발하는 단계
- **Share**: 창의적인 작업과 결과물을 공유하고 확산하는 단계
#### Connect
- [[📖 100 Themes]] — 관심사, 주제, 변수, 용어 정의
#### Merge
- [[📖 200 Literature]] — 개념, 프레임워크, 이론, 문헌리뷰, 도서, 성경/설교
#### Develop
- [[📖 300 Data]] — 척도개발, 설문, 패널데이터, DB, LMS
- [[📖 400 Methodologies]] — 연구방법, 통계, ML/DL, 코드/프롬프트/스크립트
- [[📖 500 Products]] — Obsidian, ChatGPT, Claude, Gemini, Midjourney, n8n
- [[📖 600 Specialties]] — KM, Second Brain, Gen AI, 생산성, 교육, 영성
#### Share
- [[📖 700 Creatives]] — YouTube, SNS, 음악, 재즈, 이미지, 디지털아트
- [[📖 800 Outputs]] — PhD, 논문, 강의, 컨설팅, 프로젝트, 커뮤니티
- [[📖 900 Divisions]] — 9개 운영 부문 (KM, 교육, 컨설팅 등)

## CMDS Process Commands (2026-04-14+)
> [!tip] CMDS Process의 operational verbs
> 4단계 프로세스 각각에 대응하는 슬래시 커맨드. Claude Code 세션에서 `/command` 형태로 실행. 정의 파일: `90. Settings/94. Agent Settings/claude/commands/`

#### Stage Commands
- `/connect` — inbox 항목을 [[📖 100 Themes]] stub 으로 빠르게 등록 (자동 분류/중복제거)
- `/merge` — N개 노트 → 1개 [[📖 200 Literature]] 합성 (multi-dialog: purpose/candidate/angle/draft)
- `/develop` — method + data → [[📖 400 Methodologies]] artifact (code/prompt/curriculum) 생성
- `/share` — 기존 합성을 [[📖 700 Creatives]] / [[📖 800 Outputs]] 로 포맷 변환 (skill 오케스트레이션)

#### Cross-cutting Utilities
- `/inbox` — `00. Inbox/` 스캔 + AskUserQuestion 으로 stage 라우팅
- `/lint {scope}` — 단계별 위생 점검 (orphan/contradiction/stale/frontmatter coverage)
- `/query` — 볼트 + LLM Wiki 검색, 답변은 해당 CMDS 카테고리에 file-back (별도 폴더 없음)
- `/status` — 단계별 노트 수 + 추천 액션 한 화면 요약

> 세부 문서: [[CLAUDE.md]] "CMDS Process Command Suite" 섹션 / [[🏛 CMDS Guide]] "CMDS Process Command Fields (v2.2)" 섹션

## Vault Folders
> [!tip] 폴더 구조 (00-90)
> CMDS 카테고리(100-900)와 별도로, 볼트의 물리적 폴더 구조입니다.

- `00. Inbox/` — 임시 저장 (Daily Notes, Clippings, AI Agent, Canvas, Automation)
- `10. CMDS Process/` — Connect→Merge→Develop→Share 워크플로우
- `20. Literature Notes/` — 문헌 노트, 리뷰, 설교, 용어
- `30. Permanent Notes/` — 에세이, 가이드라인 (Evergreen)
- `40. Docs/` — 기술 문서, 오디오, 트랜스크립트, API 정보
- `50. Assets/` — 브랜드, 프롬프트, 워크플로우, 웹 클리퍼
- `60. Collections/` — People, Organization, Meetings, Spirituality, Preferences
- `70. Outputs/` — Published, Presentations, Courses, Projects, Consulting
- `80. References/` — Attachment, 웹 아티클, Zotero, 도서
- `90. Settings/` — Templates, System Prompts, Fonts, Index
## Working Environments
> [!info] Obsidian Sync (공식 클라우드)
> 두 대의 Mac이 **Obsidian Sync**로 동기화됩니다. 모든 하위 경로와 파일이 동일하게 유지됩니다.

| 환경 | 기기 | AI 코드 출력 폴더 |
|------|------|--------------------|
| Primary | MacBook Pro | `03-1. Claude Code (MBP)` / `03-3. OpenClaw (MBP)` |
| Secondary | Mac Studio | `03-2. Claude Code (Studio)` / `03-4. OpenClaw (Studio)` |

## Satellite Vaults
> [!tip] 이 볼트의 자매 볼트
> CMDSPACE_Local_MBP 옆에 특수 목적 satellite 볼트가 있습니다. Obsidian Sync 별개이며 각자 독립 git repo로 관리됩니다.

| Satellite | 경로 | 목적 | 진입점 |
|-----------|------|------|--------|
| `CMDS_LLM_Wiki` | `/Users/yohankoo/Local Obsidian_MBP/CMDS_LLM_Wiki` | Karpathy LLM Wiki 패턴 구현 — LLM이 raw source를 컴파일하여 영속 위키 유지 | [[🛰 CMDS_LLM_Wiki Satellite Vault]] |

- 사용 기준: 외부 자료(기사·논문·전사)를 LLM이 통합 관리하는 주제별 deep-dive는 satellite에, 그 외 PKM은 메인 볼트에.
- Cross-reference 규약: [[🛰 CMDS_LLM_Wiki Satellite Vault#5. Cross-Reference Convention]] 참조.
